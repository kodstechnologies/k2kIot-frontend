import { lazy } from 'react';
const Error = lazy(() => import('../components/Error'));
const Dashboard = lazy(() => import('../pages/Index'));
const Faq = lazy(() => import('../pages/Faq'));

import { 
    OperatorView, 
    OperatorCreate, 
    WorkOrderView, 
    WorkOrderCreate, 
    ProductionPlanningView, 
    ProductionPlanningCreate, 
    JobOrderView, 
    JobOrderCreate, 
    PackingView, 
    PackingCreate, 
    DispatchView, 
    DispatchCreate, 
    DipatchInvoiceView,
    HelperClients,
    HelperClientCreate,
    Helper1, 
    Helper2 
} from '../pages/Apps/Konkrete-Klinkers';

// User-specific components
const UsersProfile = lazy(() => import('@/pages/Apps/Users/Profile'));
const UsersAccountSettings = lazy(() => import('@/pages/Apps/Users/AccountSetting'));

const adminRoutes = [
    {
        path: '/',
        element: <Dashboard />,
        layout: 'admin',
    },
    {
        path: '/faq',
        element: <Faq />,
        layout: 'admin',
    },
    // Work Order
    {
        path: '/konkrete-klinkers/work-order/view',
        element: <WorkOrderView />,
        layout: 'admin',
    },
    {
        path: '/konkrete-klinkers/work-order/create',
        element: <WorkOrderCreate />,
        layout: 'admin',
    },
        // Job Order
        {
            path: '/konkrete-klinkers/job-order/view',
            element: <JobOrderView />,
            layout: 'admin',
        },
        {
            path: '/konkrete-klinkers/job-order/create',
            element: <JobOrderCreate />,
            layout: 'admin',
        },
    // Production Planning
    {
        path: '/konkrete-klinkers/production-planning/view',
        element: <ProductionPlanningView />,
        layout: 'admin',
    },
    {
        path: '/konkrete-klinkers/production-planning/create',
        element: <ProductionPlanningCreate />,
        layout: 'admin',
    },
    // Operator
    {
        path: '/konkrete-klinkers/operator/view',
        element: <OperatorView />,
        layout: 'admin',
    },
    {
        path: '/konkrete-klinkers/operator/create',
        element: <OperatorCreate />,
        layout: 'admin',
    },
    // Packing
    {
        path: '/konkrete-klinkers/packing/view',
        element: <PackingView />,
        layout: 'admin',
    },
    {
        path: '/konkrete-klinkers/packing/create',
        element: <PackingCreate />,
        layout: 'admin',
    },
    // Dispatch
    {
        path: '/konkrete-klinkers/dispatch/view',
        element: <DispatchView />,
        layout: 'admin',
    },
    {
        path: '/konkrete-klinkers/dispatch/create',
        element: <DispatchCreate />,
        layout: 'admin',
    },
    {
        path: '/konkrete-klinkers/dispatch/invoice/view',
        element: <DipatchInvoiceView />,
        layout: 'admin',
    },

    //HELPERS CLIENTS
    {
        path: '/konkrete-klinkers/helpers/clients',
        element: <HelperClients />,
        layout: 'admin',
    },
    {
        path: '/konkrete-klinkers/helpers/clients/create',
        element: <HelperClientCreate />,
        layout: 'admin',
    },
    {
        path: '/konkrete-klinkers/helpers/cients/edit/:id',
        element: <HelperClientCreate />,
        layout: 'admin',
    },

    // Helpers(dummy pages to show)
    {
        path: '/konkrete-klinkers/helpers/helper1',
        element: <Helper1 />,
        layout: 'admin',
    },
    {
        path: '/konkrete-klinkers/helpers/helper2',
        element: <Helper2 />,
        layout: 'admin',
    },
    // User Routes
    {
        path: '/users/profile',
        element: <UsersProfile />,
        layout: 'default',
    },
    {
        path: '/users/edit',
        element: <UsersAccountSettings />,
        layout: 'default',
    },
    // Catch-all
    {
        path: '*',
        element: <Error />,
        layout: 'blank',
    },
];

export default adminRoutes;
