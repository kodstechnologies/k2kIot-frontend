import React from 'react'

const view = () => {
  return (
    <div>
      View
    </div>
  )
}

export default view
