import React from 'react'

const create = () => {
  return (
    <div>
      Create
    </div>
  )
}

export default create
