import React from 'react'

const view = () => {
  return (
    <div>
      Clients view
    </div>
  )
}

export default view
