import React, { useEffect, useState } from 'react';
import { DataTable, DataTableSortStatus } from 'mantine-datatable';
import sortBy from 'lodash/sortBy';
import { fetchAllClients } from '@/api/clients'; // Adjust the import based on your API file
import Breadcrumbs from "@/pages/Components/Breadcrumbs";

interface Client {
    clientName: string;
    created_by: string;
    index?: number;
}

const ColumnChooser = () => {
    const PAGE_SIZES = [10, 20, 30, 50, 100];

    // State Variables
    const [clients, setClients] = useState([]);
    const [filteredClients, setFilteredClients] = useState([]);
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(PAGE_SIZES[0]);
    const [search, setSearch] = useState('');
    const [sortStatus, setSortStatus] = useState<DataTableSortStatus>({
        columnAccessor: 'index',
        direction: 'asc',
    });

    // Fetch Clients from API
    // useEffect(() => {
    //     const fetchClients = async () => {
    //         try {
    //             const data = await fetchAllClients(); // Assuming API returns an array of { clientName, created_by }
    //             // Add sequential index
    //             const indexedData = data.map((client, idx) => ({
    //                 ...client,
    //                 index: idx + 1, // Sequential ID starting from 1
    //             }));
    //             setClients(indexedData);
    //             setFilteredClients(sortBy(indexedData, 'index')); // Default sorted by index
    //         } catch (error) {
    //             console.error('Error fetching clients:', error);
    //         }
    //     };
    //     fetchClients();
    // }, []);

    // Handle Pagination
    useEffect(() => {
        const from = (page - 1) * pageSize;
        const to = from + pageSize;
        setFilteredClients([...clients.slice(from, to)]);
    }, [page, pageSize, clients]);

    // Handle Search
    useEffect(() => {
        const filtered = clients.filter((client) =>
            ['index', 'clientName'].some((key) =>
                client[key]?.toString().toLowerCase().includes(search.toLowerCase())
            )
        );
        setFilteredClients(filtered);
    }, [search, clients]);

    // Handle Sorting
    useEffect(() => {
        const sorted = sortBy(clients, sortStatus.columnAccessor);
        setFilteredClients(sortStatus.direction === 'desc' ? sorted.reverse() : sorted);
        setPage(1); // Reset to first page after sorting
    }, [sortStatus, clients]);

    return (
        <div>
            <Breadcrumbs
                items={[
                    { label: 'Home', link: '/', isActive: false },
                    { label: 'Clients', link: '/clients', isActive: true },
                ]}
                addButton={{ label: 'Add Client', link: '/konkrete-klinkers/helpers/clients/create' }}
            />

            <div className="panel mt-6">
                <div className="flex md:items-center md:flex-row flex-col mb-5 gap-5">
                    <h5 className="font-semibold text-lg dark:text-white-light">Clients</h5>
                    <div className="flex items-center gap-5 ltr:ml-auto rtl:mr-auto">
                        <input
                            type="text"
                            className="form-input"
                            placeholder="Search by name"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                </div>
                <div className="datatables">
                    <DataTable
                        className="whitespace-nowrap table-hover"
                        records={filteredClients}
                        columns={[
                            { accessor: 'index', title: 'ID', sortable: true },
                            { accessor: 'clientName', title: 'Client Name', sortable: true },
                            { accessor: 'created_by', title: 'Created By', sortable: true },
                        ]}
                        highlightOnHover
                        totalRecords={clients.length}
                        recordsPerPage={pageSize}
                        page={page}
                        onPageChange={(p) => setPage(p)}
                        recordsPerPageOptions={PAGE_SIZES}
                        onRecordsPerPageChange={setPageSize}
                        sortStatus={sortStatus}
                        onSortStatusChange={setSortStatus}
                        minHeight={200}
                        paginationText={({ from, to, totalRecords }) => `Showing ${from} to ${to} of ${totalRecords} entries`}
                    />
                </div>
            </div>
        </div>
    );
};

export default ColumnChooser;
