import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {  useSelector } from 'react-redux';

import { IRootState } from "@/store"


const ClientCreation = () => {
  const   baseURL= import.meta.env.VITE_APP_SERVER_URL;
    const userDetail = useSelector((state: IRootState) => state.auth.user) || 'Guest User';

console.log("userdetaila", baseURL)
    const [formData, setFormData] = useState({
        name: '',
    });
    const navigate = useNavigate();

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            // Example API call to create a client
            const userId =userDetail._id ;
            const response = await fetch(`${baseURL}/konkreteKlinkers/helpers/clients`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('accessToken')}`, // Pass the token here
                },
                body: JSON.stringify({ ...formData, created_by: userId }),
            });
            
            if (!response.ok) {
                throw new Error('Failed to create client');
            }
            console.log('Client created successfully');
            navigate('/clients');
        } catch (error) {
            console.error('Error creating client:', error);
        }
    };

    return (
        <div>
            <ul className="flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link to="/clients" className="text-primary hover:underline">
                        Clients
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>Create</span>
                </li>
            </ul>
            <div className="panel">
                <div className="mb-5">
                    <h5 className="font-semibold text-lg">Client Creation</h5>
                </div>
                <form className="space-y-5" onSubmit={handleSubmit}>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="name">Client Name</label>
                            <input
                                id="name"
                                name="name"
                                type="text"
                                placeholder="Enter Client Name"
                                className="form-input"
                                value={formData.name}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                    </div>

                    <div className="flex justify-end space-x-4">
                        {/* Cancel Button */}
                        <button
                            type="button"
                            className="btn btn-secondary"
                            onClick={() => navigate('/clients')}
                        >
                            Cancel
                        </button>
                        {/* Submit Button */}
                        <button type="submit" className="btn btn-primary">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ClientCreation;
